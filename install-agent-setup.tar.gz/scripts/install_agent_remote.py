#!/usr/bin/env python3
"""Download the latest release and install the inventory agent over SSH."""

from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
AGENT_DIR = ROOT
DEPLOY_DIR = ROOT / "deploy"
REMOTE_CONFIG = "/etc/vulnerability-agent/agent.env"
PUBLIC_RELEASE_REPOSITORY = "deepak-cyberbear/asset-inventory-agent-releases"
DEFAULT_API_URL = "https://vul-mvp-api.jollyflower-3d0dfe1b.centralindia.azurecontainerapps.io"

RELEASE_TARGETS = {
    "x86_64": "amd64",
    "aarch64": "arm64",
    "arm64": "arm64",
}

BUILD_TARGETS = {
    "x86_64": ("amd64", "build-agent-linux-amd64"),
    "aarch64": ("arm64", "build-agent-linux-arm64"),
    "arm64": ("arm64", "build-agent-linux-arm64"),
    "armv7l": ("armv7", "build-agent-linux-armv7"),
    "i386": ("386", "build-agent-linux-386"),
    "i686": ("386", "build-agent-linux-386"),
}


class InstallError(RuntimeError):
    """An actionable error while preparing or installing the remote agent."""


def parse_ip(value: str) -> str:
    """Accept an IPv4 or IPv6 address, not a hostname or SSH destination string."""
    try:
        return str(ipaddress.ip_address(value))
    except ValueError as exc:
        raise InstallError(f"{value!r} is not a valid IP address") from exc


def parse_api_url(value: str) -> str:
    """Validate an API base URL suitable for the agent's inventory POST endpoint."""
    if any(character.isspace() or ord(character) < 32 for character in value):
        raise InstallError("API_URL cannot contain whitespace or control characters")
    try:
        parsed = urlsplit(value)
        _ = parsed.port
    except ValueError as exc:
        raise InstallError("API_URL is malformed") from exc
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise InstallError("API_URL must be an http(s) base URL without credentials or query")
    return value.rstrip("/")


def systemd_quote(value: str) -> str:
    """Quote one systemd EnvironmentFile value without allowing extra lines."""
    if any(ord(character) < 32 or ord(character) == 127 for character in value):
        raise InstallError("agent configuration values cannot contain control characters")
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def render_agent_config(api_url: str, device_id: str) -> str:
    """Create the root-owned systemd environment file used by the agent service."""
    if not device_id.strip():
        raise InstallError("DEVICE_ID cannot be empty")
    return "\n".join(
        (
            f"AGENT_API_URL={systemd_quote(parse_api_url(api_url))}",
            f"AGENT_DEVICE_ID={systemd_quote(device_id)}",
            'AGENT_STATE_DIR="/var/lib/vulnerability-agent"',
            "",
        )
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Download the latest agent release and install it over SSH."
    )
    parser.add_argument("ip", nargs="?", default=os.environ.get("IP"))
    parser.add_argument("--ssh-user", default=os.environ.get("SSH_USER", "ubuntu"))
    parser.add_argument("--ssh-port", type=int, default=os.environ.get("SSH_PORT", "22"))
    parser.add_argument(
        "--api-url",
        default=os.environ.get("API_URL") or DEFAULT_API_URL,
        help="backend API base URL (defaults to the Azure pilot)",
    )
    parser.add_argument("--device-id", default=os.environ.get("DEVICE_ID") or None)
    parser.add_argument(
        "--reconfigure",
        action="store_true",
        default=os.environ.get("RECONFIGURE", "0").lower() in {"1", "true", "yes"},
        help="replace the existing agent API URL and device ID",
    )
    parser.add_argument(
        "--build-from-source",
        action="store_true",
        help="build locally instead of downloading a GitHub Release (development use)",
    )
    return parser.parse_args()


def ssh_destination(ip: str, username: str, *, scp: bool = False) -> str:
    if ":" in ip and scp:
        return f"{username}@[{ip}]"
    return f"{username}@{ip}"


def ssh_command(
    ip: str,
    username: str,
    port: int,
    remote_command: str,
    *,
    tty: bool = False,
) -> list[str]:
    command = ["ssh", "-p", str(port), "-o", "ConnectTimeout=10"]
    if tty:
        command.append("-tt")
    command.extend((ssh_destination(ip, username), remote_command))
    return command


def run(
    command: list[str],
    *,
    capture: bool = False,
    allow_failure: bool = False,
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(  # noqa: S603 - executable names and arguments are validated.
            command,
            check=not allow_failure,
            text=True,
            capture_output=capture,
        )
    except FileNotFoundError as exc:
        raise InstallError(f"Required command not found: {command[0]}") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        message = f"Command failed: {shlex.join(command)}"
        if detail:
            message += f"\n{detail}"
        raise InstallError(message) from exc


def prompt_api_url(value: str | None) -> str:
    if not value:
        prompt = "Backend API base URL reachable from the Ubuntu machine: "
        try:
            with open("/dev/tty", "r+", encoding="utf-8") as terminal:
                print(prompt, end="", file=terminal, flush=True)
                value = terminal.readline().strip()
        except OSError:
            if not sys.stdin.isatty():
                raise InstallError(
                    "Set AGENT_API_URL or run with a terminal to enter the backend URL"
                )
            value = input(prompt).strip()
        if not value:
            raise InstallError("API_URL cannot be empty")
    return parse_api_url(value)


def probe_host(ip: str, username: str, port: int) -> tuple[str, str, str]:
    remote = (
        "set -eu; . /etc/os-release; "
        "[ \"$ID\" = ubuntu ] || { echo 'Target must be Ubuntu' >&2; exit 3; }; "
        "command -v systemctl >/dev/null || { echo 'systemd is required' >&2; exit 4; }; "
        'printf \'%s\\n%s\\n%s\\n\' "$VERSION_ID" "$(uname -m)" "$(hostname -s)"'
    )
    result = run(ssh_command(ip, username, port, remote), capture=True)
    lines = result.stdout.splitlines()
    if len(lines) != 3:
        raise InstallError("Could not determine target Ubuntu version, architecture, and hostname")
    return lines[0], lines[1], lines[2]


def remote_config_exists(ip: str, username: str, port: int) -> bool:
    """Check for an existing config interactively so sudo prompts remain visible."""
    remote = (
        "sudo -v || exit 2; "
        f"if sudo test -f {shlex.quote(REMOTE_CONFIG)}; then exit 0; "
        'else result=$?; [ "$result" -eq 1 ] && exit 1; exit "$result"; fi'
    )
    result = run(
        ssh_command(ip, username, port, remote, tty=True),
        allow_failure=True,
    )
    if result.returncode == 0:
        return True
    if result.returncode == 1:
        return False
    raise InstallError("Could not check remote agent config; confirm SSH and sudo access")


def build_agent(remote_arch: str) -> Path:
    try:
        artifact_arch, make_target = BUILD_TARGETS[remote_arch]
    except KeyError as exc:
        supported = ", ".join(sorted(BUILD_TARGETS))
        raise InstallError(
            f"Unsupported target architecture {remote_arch!r}; supported: {supported}"
        ) from exc
    run(["make", "-C", str(ROOT), make_target])
    binary = AGENT_DIR / "bin" / f"vulnerability-agent-linux-{artifact_arch}"
    if not binary.is_file():
        raise InstallError(f"Build completed without producing {binary}")
    return binary


def verify_release_checksum(binary: Path, checksum_file: Path, asset_name: str) -> None:
    """Verify a downloaded release binary against its SHA256SUMS entry."""
    expected_digest: str | None = None
    for line in checksum_file.read_text(encoding="utf-8").splitlines():
        fields = line.split(maxsplit=1)
        if len(fields) != 2:
            continue
        filename = fields[1].strip().lstrip("*")
        if filename == asset_name:
            expected_digest = fields[0].lower()
            break

    if expected_digest is None or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        raise InstallError(f"SHA256SUMS has no valid checksum for {asset_name}")

    digest = hashlib.sha256()
    with binary.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != expected_digest:
        raise InstallError(f"Checksum verification failed for {asset_name}")


def download_release_agent(remote_arch: str, download_dir: Path) -> tuple[str, Path]:
    """Download and verify the latest matching public GitHub release asset."""
    try:
        artifact_arch = RELEASE_TARGETS[remote_arch]
    except KeyError as exc:
        supported = ", ".join(sorted(RELEASE_TARGETS))
        raise InstallError(
            f"Published releases support {supported}; use --build-from-source for "
            f"{remote_arch!r}"
        ) from exc

    asset_name = f"vulnerability-agent-linux-{artifact_arch}"
    api_url = (
        "https://api.github.com/repos/"
        f"{PUBLIC_RELEASE_REPOSITORY}/releases/latest"
    )
    request = Request(
        api_url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "asset-inventory-agent-installer",
        },
    )
    try:
        with urlopen(request, timeout=30) as response:
            release = json.load(response)
        tag = release["tag_name"]
        assets = release["assets"]
    except (HTTPError, URLError, TimeoutError, OSError) as exc:
        raise InstallError(
            f"Could not read the latest public release from {PUBLIC_RELEASE_REPOSITORY}: {exc}"
        ) from exc
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        raise InstallError("GitHub returned invalid latest-release metadata") from exc
    if not isinstance(tag, str) or not tag or not isinstance(assets, list):
        raise InstallError("GitHub returned invalid latest-release metadata")

    download_dir.mkdir(parents=True, exist_ok=True)

    asset_urls = {
        asset.get("name"): asset.get("browser_download_url")
        for asset in assets
        if isinstance(asset, dict)
    }
    if asset_name not in asset_urls:
        raise InstallError(f"Latest release {tag} does not contain {asset_name}")
    if "SHA256SUMS" not in asset_urls:
        raise InstallError(f"Latest release {tag} does not contain SHA256SUMS")

    binary = download_dir / asset_name
    checksum_file = download_dir / "SHA256SUMS"
    for name, destination in ((asset_name, binary), ("SHA256SUMS", checksum_file)):
        download_url = asset_urls[name]
        if not isinstance(download_url, str):
            raise InstallError(f"GitHub returned an invalid download URL for {name}")
        parsed_url = urlsplit(download_url)
        expected_prefix = f"/{PUBLIC_RELEASE_REPOSITORY}/releases/download/"
        if (
            parsed_url.scheme != "https"
            or parsed_url.netloc != "github.com"
            or not parsed_url.path.startswith(expected_prefix)
        ):
            raise InstallError(f"GitHub returned an unexpected download URL for {name}")
        asset_request = Request(
            download_url,
            headers={"User-Agent": "asset-inventory-agent-installer"},
        )
        try:
            with urlopen(asset_request, timeout=120) as response, destination.open("wb") as output:
                shutil.copyfileobj(response, output)
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise InstallError(f"Could not download {name} from release {tag}: {exc}") from exc

    if not binary.is_file() or not checksum_file.is_file():
        raise InstallError(f"GitHub did not download all required assets for release {tag}")
    verify_release_checksum(binary, checksum_file, asset_name)
    return tag, binary


def stage_files(binary: Path, config: str | None) -> tempfile.TemporaryDirectory[str]:
    staging = tempfile.TemporaryDirectory(prefix="vulnerability-agent-install-")
    staging_dir = Path(staging.name)
    shutil.copyfile(binary, staging_dir / "vulnerability-agent")
    (staging_dir / "vulnerability-agent").chmod(0o755)
    for unit in (
        "vulnerability-agent.service",
        "vulnerability-agent.timer",
        "vulnerability-agent.path",
    ):
        shutil.copyfile(DEPLOY_DIR / unit, staging_dir / unit)
    if config is not None:
        config_path = staging_dir / "agent.env"
        config_path.write_text(config, encoding="utf-8")
        config_path.chmod(0o600)
    return staging


def install_remote(
    ip: str,
    username: str,
    port: int,
    staging_dir: Path,
    *,
    install_config: bool,
) -> None:
    remote_stage = f"/tmp/vulnerability-agent-install-{uuid.uuid4().hex}"  # noqa: S108 - unique mode-0700 staging directory.
    quoted_stage = shlex.quote(remote_stage)
    run(
        ssh_command(
            ip,
            username,
            port,
            f"umask 077 && mkdir -m 700 -- {quoted_stage}",
        )
    )
    remote_copy_target = f"{ssh_destination(ip, username, scp=True)}:{remote_stage}/"
    scp_command = [
        "scp",
        "-P",
        str(port),
        "-o",
        "ConnectTimeout=10",
        *[str(path) for path in sorted(staging_dir.iterdir())],
        remote_copy_target,
    ]
    try:
        run(scp_command)
        install_config_command = (
            f"sudo install -o root -g root -m 0600 {quoted_stage}/agent.env {REMOTE_CONFIG}"
            if install_config
            else f"sudo test -f {shlex.quote(REMOTE_CONFIG)} || {{ "
            "echo 'Agent config disappeared; rerun with RECONFIGURE=1 to create it.' >&2; exit 1; }"
        )
        remove_legacy_token_command = (
            "true"
            if install_config
            else f"sudo sed -i '/^AGENT_UPLOAD_TOKEN=/d' {shlex.quote(REMOTE_CONFIG)}"
        )
        remote_install = "\n".join(
            (
                "set -eu",
                f"stage={quoted_stage}",
                "trap 'rm -rf -- \"$stage\"' EXIT",
                "sudo install -d -o root -g root -m 0750 /etc/vulnerability-agent",
                f"sudo install -o root -g root -m 0755 {quoted_stage}/vulnerability-agent "
                "/usr/local/bin/vulnerability-agent",
                f"sudo install -o root -g root -m 0644 {quoted_stage}/vulnerability-agent.service "
                f"{quoted_stage}/vulnerability-agent.timer {quoted_stage}/vulnerability-agent.path "
                "/etc/systemd/system/",
                install_config_command,
                remove_legacy_token_command,
                "sudo systemctl daemon-reload",
                "sudo systemctl enable --now vulnerability-agent.timer vulnerability-agent.path",
                "sudo systemctl start vulnerability-agent.service",
                "sudo systemctl --no-pager show -p Result -p ExecMainStatus "
                "vulnerability-agent.service",
                "sudo journalctl -u vulnerability-agent.service -n 20 --no-pager",
            )
        )
        run(ssh_command(ip, username, port, remote_install, tty=True))
    finally:
        cleanup = f"rm -rf -- {quoted_stage}"
        run(ssh_command(ip, username, port, cleanup), allow_failure=True)


def main() -> int:
    args = parse_args()
    if not args.ip:
        raise InstallError("Provide the target IP, for example: make install-agent IP=192.168.1.25")
    ip = parse_ip(args.ip.strip())
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", args.ssh_user):
        raise InstallError(
            "SSH_USER may contain only letters, digits, dots, underscores, and dashes"
        )
    if not 1 <= args.ssh_port <= 65535:
        raise InstallError("SSH_PORT must be between 1 and 65535")

    version, remote_arch, hostname = probe_host(ip, args.ssh_user, args.ssh_port)
    if remote_arch not in BUILD_TARGETS:
        supported = ", ".join(sorted(BUILD_TARGETS))
        raise InstallError(
            f"Unsupported target architecture {remote_arch!r}; supported: {supported}"
        )
    config_exists = remote_config_exists(ip, args.ssh_user, args.ssh_port)
    install_config = not config_exists or args.reconfigure

    if config_exists and not args.reconfigure:
        print(f"Existing agent config found on {hostname}; keeping its URL and device ID.")
        print("Set RECONFIGURE=1 to replace that configuration.")
        config = None
    else:
        api_url = prompt_api_url(args.api_url)
        parsed_url = urlsplit(api_url)
        if parsed_url.scheme == "http":
            print(
                "Warning: HTTP does not encrypt inventory data; use only on a trusted local "
                "network. Use HTTPS outside local development.",
                file=sys.stderr,
            )
        api_host = parsed_url.hostname or ""
        if api_host.lower() == "localhost" or api_host in {"127.0.0.1", "::1"}:
            print(
                "Warning: localhost in API_URL refers to the Ubuntu target itself. "
                "Use a reachable backend address if the API runs elsewhere.",
                file=sys.stderr,
            )
        device_id = args.device_id or hostname
        config = render_agent_config(api_url, device_id)
        print(f"Configuring stable device ID: {device_id}")

    release_temp: tempfile.TemporaryDirectory[str] | None = None
    staging: tempfile.TemporaryDirectory[str] | None = None
    try:
        if args.build_from_source:
            print(f"Building {remote_arch} agent for Ubuntu {version} on {hostname}...")
            binary = build_agent(remote_arch)
        else:
            print(f"Downloading latest release for Ubuntu {version} on {hostname}...")
            release_temp = tempfile.TemporaryDirectory(prefix="vulnerability-agent-release-")
            release_tag, binary = download_release_agent(remote_arch, Path(release_temp.name))
            print(f"Using agent release {release_tag} ({binary.name}).")

        staging = stage_files(binary, config)
        install_remote(
            ip,
            args.ssh_user,
            args.ssh_port,
            Path(staging.name),
            install_config=install_config,
        )
    finally:
        if staging is not None:
            staging.cleanup()
        if release_temp is not None:
            release_temp.cleanup()
    print(f"Agent installed on {args.ssh_user}@{ip}; review its report in /ui/assets.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except InstallError as exc:
        print(f"Agent install failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
